import sys, re, hashlib, email
from email import policy

msg = email.message_from_binary_file(open(sys.argv[1], 'rb'), policy=policy.default)

print("== CABECALHOS ==")
for h in ['From', 'Reply-To', 'Return-Path', 'To', 'Subject', 'Date', 'Message-ID', 'X-Originating-IP']:
    print(f"{h}: {msg.get(h)}")

print("\n== RECEIVED (do primeiro salto ao ultimo) ==")
for i, r in enumerate(reversed(msg.get_all('Received', [])), 1):
    print(f"{i}. {' '.join(str(r).split())[:200]}")

print("\n== AUTENTICACAO ==")
print(msg.get('Authentication-Results'))

print("\n== URLS ==")
urls = set()
for part in msg.walk():
    if part.get_content_maintype() == 'text':
        try:
            urls.update(re.findall(r'https?://[^\s"\'<>]+', part.get_content()))
        except Exception:
            pass
for u in sorted(urls):
    print(u.replace('http', 'hxxp', 1).replace('.', '[.]'))

print("\n== ANEXOS ==")
for part in msg.walk():
    nome = part.get_filename()
    if nome:
        dados = part.get_payload(decode=True) or b''
        print(f"{nome} | {part.get_content_type()} | {len(dados)} bytes | SHA256 {hashlib.sha256(dados).hexdigest()}")
